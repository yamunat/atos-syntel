import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'example';
  Days
   = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
   isavailable = true; 
   myClickFunction(event) {
      
      alert("Button is clicked");
      console.log(event);
   }
}
