import { Component, OnInit } from '@angular/core';
import { MyserviceService } from '../myservice.service';

@Component({
  selector: 'app-new-comp',
  templateUrl: './new-comp.component.html',
  styleUrls: ['./new-comp.component.css']
})
export class NewCompComponent implements OnInit {
    todaydate; 
   newcomponentproperty; 
   newcomponent = "Entered in newcomponent";
  constructor(private myservice: MyserviceService) { }

  ngOnInit(): void {
    this.todaydate = this.myservice.showTodayDate(); 
    this.newcomponentproperty = this.myservice.serviceproperty; 
  }

}
